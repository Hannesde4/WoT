Dit is een simpele UI met enkele buttons.
Met deze buttons kun je een domotica systeem besturen, dit wordt voorgesteld door de ledjes op senseHat van de raspberry pi.

Alle data wordt realtime opgeslaan in de firestore database.